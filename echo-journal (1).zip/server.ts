import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '1mb' }));

// Shared Gemini client instance (server-side only)
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Acute crisis safety detector
const CRISIS_KEYWORDS = [
  'kill myself',
  'suicide',
  'suicidal',
  'end my life',
  'want to die',
  'better off dead',
  'take my own life',
  'hang myself',
  'slit my wrist',
  'self harm',
  'cut myself',
];

function checkCrisisText(text: string): boolean {
  if (!text) return false;
  const lower = text.toLowerCase();
  return CRISIS_KEYWORDS.some(k => lower.includes(k));
}

const CRISIS_RESPONSE = {
  crisisDetected: true,
  message:
    "We care deeply about your wellbeing. If you or someone you know is in distress or having thoughts of self-harm, please know that immediate, confidential, and free support is available 24/7:",
  helplines: [
    { country: 'US & Canada', name: 'Suicide & Crisis Lifeline', contact: 'Call or text 988', url: 'https://988lifeline.org' },
    { country: 'United Kingdom', name: 'Samaritans', contact: 'Call 116 123', url: 'https://www.samaritans.org' },
    { country: 'India', name: 'Tele-MANAS', contact: '14416 / 1800-891-4416', url: 'https://telemanas.mohfw.gov.in' },
    { country: 'International', name: 'Befrienders Worldwide / IASP', contact: 'Find local support', url: 'https://findahelpline.com' },
  ],
  disclaimer: 'Echo Journal is a personal reflection tool and cannot substitute for clinical care or emergency crisis response.',
};

// Chat API endpoint
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { messages, optInExternalAi, userEntriesSnippet } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: 'Messages array is required.' });
      return;
    }

    const latestMessage = messages[messages.length - 1];
    const userPrompt = latestMessage.content || '';

    // Step 1: Crisis safety check
    if (checkCrisisText(userPrompt)) {
      res.json(CRISIS_RESPONSE);
      return;
    }

    // Step 2: API key check
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      res.status(200).json({
        crisisDetected: false,
        text: "I am ready to reflect with you, but the GEMINI_API_KEY is not currently configured in the environment. Please add it via the Settings > Secrets panel to enable interactive reflection.",
        model: 'gemini-3.8-flash',
        simulated: true,
      });
      return;
    }

    // Step 3: Build system instruction & contents
    let systemInstruction = `You are Echo, the thoughtful, empathetic reflection companion inside Echo Journal.
Your purpose is to help users reflect upon their thoughts, unpack their emotional states, and foster self-awareness.

NON-NEGOTIABLE CORE GUIDELINES:
1. SELF-REFLECTION ONLY, NOT MEDICINE: You are not a medical professional, therapist, or diagnostic system. NEVER diagnose psychological, psychiatric, or physical illnesses. NEVER prescribe medications or therapeutic interventions.
2. CORRELATIONAL LANGUAGE ONLY, NEVER CAUSATION: When discussing moods, patterns, or feelings, never claim that one event or mood caused another. Use gentle observational phrasing (e.g., "it appears you frequently note feeling reflective when...", "you observed that...", "these thoughts co-occur with...").
3. GROUND TRUTH & CITATIONS: If journal notes or retrieved entries are provided below, cite them faithfully with dates and topics. Never invent or hallucinate journal entries. If an entry is not present, honestly acknowledge: "I don't see that in your recorded reflections."
4. CRISIS SUPPRESSION: If the user expresses active intent to self-harm, immediately direct them to emergency services or 988.
5. TONE: Warm, poetic yet grounded, calm, conversational, and genuinely supportive without being overly chatty or patronizing. Keep answers focused (2-4 paragraphs max).`;

    if (optInExternalAi && userEntriesSnippet) {
      systemInstruction += `\n\n--- RECENT JOURNAL CONTEXT (AUTHORIZED BY USER) ---\n${userEntriesSnippet}\n--- END CONTEXT ---`;
    }

    // Format conversation history for Gemini generateContent
    // Map previous messages to Gemini contents structure
    const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

    // Include last up to 8 turns for context
    const recentMessages = messages.slice(-8);
    for (const msg of recentMessages) {
      contents.push({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }],
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction,
      },
    });

    const outputText = response.text || "I was unable to formulate a reflection. How else can I support your journaling today?";

    res.json({
      crisisDetected: false,
      text: outputText,
      model: 'gemini-3.8-flash',
    });
  } catch (error: any) {
    console.error('Gemini chat error:', error);
    res.status(500).json({
      error: error?.message || 'An error occurred while generating a reflection.',
      details: 'Please check your Gemini API key in the Secrets panel if this persists.',
    });
  }
});

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', service: 'echo-journal-fullstack' });
});

// Dev vs Production Vite Middleware
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Echo Journal dev server with Gemini Chatbot listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
