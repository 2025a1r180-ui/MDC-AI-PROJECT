import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  Trash2,
  Download,
  AlertTriangle,
  HeartPulse,
  Shield,
  ShieldCheck,
  CheckCircle2,
  Lock,
  ArrowRight,
  RefreshCw,
  BookOpen,
} from 'lucide-react';
import { User, JournalEntry, StorageService } from '../storage';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  model?: string;
  crisisData?: any;
}

interface GeminiChatbotProps {
  currentUser: User | null;
  entries: JournalEntry[];
  onNavigateToAccount?: () => void;
  onOpenEntry?: (id: number) => void;
}

const SUGGESTED_PROMPTS = [
  "What positive patterns have emerged in my recent journal notes?",
  "I'm feeling stressed with deadlines. How can I practice grounded self-compassion?",
  "Give me a contemplative prompt for my evening writing session.",
  "Help me reframe an anxious thought without offering medical advice.",
];

export const GeminiChatbot: React.FC<GeminiChatbotProps> = ({
  currentUser,
  entries,
  onNavigateToAccount,
  onOpenEntry,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    return [
      {
        id: 'intro-1',
        role: 'assistant',
        content: `Hello ${currentUser ? currentUser.username : 'there'}, I am **Echo**, your reflective companion powered by **Gemini 3.8 Flash**. \n\nI am here to help you explore your thoughts, reflect on emotional nuances, and gently dialogue about your personal journey. \n\n*Note: I am a self-reflection tool, not a therapist or medical system. I do not diagnose or claim causal links.*`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        model: 'gemini-3.8-flash',
      },
    ];
  });

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [useJournalContext, setUseJournalContext] = useState(currentUser?.optInExternalAi ?? false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = async (textToSend?: string) => {
    const messageContent = (textToSend || input).trim();
    if (!messageContent || isLoading) return;

    setErrorMsg(null);
    setInput('');

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: messageContent,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);

    try {
      // Prepare entries context snippet if authorized
      let contextSnippet = '';
      if (useJournalContext && currentUser?.optInExternalAi && entries.length > 0) {
        const topEntries = entries.slice(0, 5);
        contextSnippet = topEntries
          .map(
            e =>
              `• [Date: ${e.createdAt.slice(0, 10)} | Title: "${e.title}" | Mood: ${e.mood || 'unrecorded'}]\n  Excerpt: "${e.content.slice(0, 220)}..."`
          )
          .join('\n\n');
      }

      const payloadMessages = [...messages, userMsg].map(m => ({
        role: m.role,
        content: m.content,
      }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: payloadMessages,
          optInExternalAi: useJournalContext && (currentUser?.optInExternalAi ?? false),
          userEntriesSnippet: contextSnippet,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `Server returned ${res.status}`);
      }

      const data = await res.json();

      if (data.crisisDetected) {
        const assistantCrisisMsg: ChatMessage = {
          id: `crisis-${Date.now()}`,
          role: 'assistant',
          content: data.message,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          crisisData: data,
        };
        setMessages(prev => [...prev, assistantCrisisMsg]);
      } else {
        const assistantMsg: ChatMessage = {
          id: `bot-${Date.now()}`,
          role: 'assistant',
          content: data.text || 'I listened to your reflection. How does that resonate with you?',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          model: data.model || 'gemini-3.8-flash',
        };
        setMessages(prev => [...prev, assistantMsg]);
      }
    } catch (err: any) {
      console.error('Chatbot error:', err);
      setErrorMsg(err.message || 'Unable to connect to the reflection server.');
      // Add error notice in chat
      setMessages(prev => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: 'assistant',
          content: `I encountered an issue connecting to Gemini: ${err.message}. Please ensure the GEMINI_API_KEY is available in your Secrets panel.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClear = () => {
    if (confirm('Clear this reflection conversation?')) {
      setMessages([
        {
          id: 'intro-reset',
          role: 'assistant',
          content: 'Dialogue cleared. What thoughts would you like to reflect on now?',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          model: 'gemini-3.8-flash',
        },
      ]);
    }
  };

  const handleExport = () => {
    const transcript = messages
      .map(m => `### ${m.role === 'user' ? 'You' : 'Echo (Gemini)'} [${m.timestamp}]\n\n${m.content}\n\n---`)
      .join('\n\n');

    const blob = new Blob([`# Echo Journal Reflective Chat Transcript\nExported: ${new Date().toISOString()}\n\n${transcript}`], {
      type: 'text/markdown',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `echo_gemini_dialogue_${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header Bar */}
      <div className="bg-white border border-stone-200 rounded-xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 bg-stone-900 text-amber-100 rounded-lg">
              <Sparkles className="w-4 h-4" />
            </span>
            <h1 className="text-xl font-serif font-semibold text-stone-900">
              Reflective Companion (Gemini 3.8 Flash)
            </h1>
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
              Server-Side GenAI
            </span>
          </div>
          <p className="text-xs text-stone-600">
            A serene, non-judgmental space for exploratory dialogue and grounding personal reflections.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleClear}
            className="px-3 py-1.5 text-xs text-stone-600 hover:text-stone-900 border border-stone-200 hover:bg-stone-50 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            title="Reset conversation history"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear
          </button>
          <button
            onClick={handleExport}
            className="px-3 py-1.5 text-xs text-stone-600 hover:text-stone-900 border border-stone-200 hover:bg-stone-50 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            title="Export dialogue to Markdown"
          >
            <Download className="w-3.5 h-3.5" />
            Export (.md)
          </button>
        </div>
      </div>

      {/* Privacy & Context Controls */}
      <div className="bg-[#fbf9f5] border border-stone-200/80 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5">
          <Shield className="w-4 h-4 text-stone-600 shrink-0" />
          <span className="text-stone-700">
            <strong>Journal Context:</strong>{' '}
            {currentUser?.optInExternalAi ? (
              <span className="text-emerald-700 font-medium">Opt-in Active (can reference recent entries)</span>
            ) : (
              <span className="text-stone-500">Local Only (opt-in disabled in Settings)</span>
            )}
          </span>
        </div>

        <div className="flex items-center gap-3">
          {currentUser?.optInExternalAi ? (
            <label className="flex items-center gap-2 text-stone-700 cursor-pointer">
              <input
                type="checkbox"
                checked={useJournalContext}
                onChange={e => setUseJournalContext(e.target.checked)}
                className="rounded border-stone-300 text-stone-900 focus:ring-stone-500 cursor-pointer"
              />
              <span>Allow Echo to view top 5 entries</span>
            </label>
          ) : (
            <button
              onClick={onNavigateToAccount}
              className="text-stone-900 underline font-medium hover:text-stone-700 cursor-pointer"
            >
              Enable Journal Access in Settings &rarr;
            </button>
          )}
        </div>
      </div>

      {/* Main Conversation Window */}
      <div className="bg-white border border-stone-200 rounded-2xl shadow-xs overflow-hidden flex flex-col h-[520px]">
        {/* Messages Scroll Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {messages.map(msg => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div className="flex items-center gap-2 mb-1 text-[11px] text-stone-400 font-mono">
                <span>{msg.role === 'user' ? (currentUser?.username || 'You') : 'Echo'}</span>
                <span>·</span>
                <span>{msg.timestamp}</span>
                {msg.model && (
                  <span className="bg-stone-100 text-stone-600 px-1.5 py-0.2 rounded text-[10px]">
                    {msg.model}
                  </span>
                )}
              </div>

              {/* Crisis Card or Standard Message */}
              {msg.crisisData ? (
                <div className="max-w-2xl bg-red-50 border border-red-200 rounded-2xl p-5 text-stone-900 shadow-xs space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-red-100 text-red-700 rounded-xl shrink-0">
                      <HeartPulse className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-red-950 text-sm">Support & Helpline Resources</h4>
                      <p className="text-xs text-red-900 mt-1 leading-relaxed">{msg.content}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-red-200/60">
                    {msg.crisisData.helplines?.map((hl: any, idx: number) => (
                      <div key={idx} className="p-2.5 bg-white border border-red-200 rounded-xl text-xs space-y-1">
                        <div className="font-semibold text-stone-900">{hl.country}: {hl.name}</div>
                        <div className="font-mono text-red-700 font-bold">{hl.contact}</div>
                      </div>
                    ))}
                  </div>

                  <p className="text-[11px] text-red-700/80 italic">{msg.crisisData.disclaimer}</p>
                </div>
              ) : (
                <div
                  className={`max-w-2xl px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-stone-900 text-stone-100 rounded-tr-xs'
                      : 'bg-[#faf9f5] border border-stone-200/90 text-stone-800 rounded-tl-xs'
                  }`}
                >
                  <div className="whitespace-pre-wrap">{msg.content}</div>
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex flex-col items-start space-y-2">
              <div className="flex items-center gap-2 text-[11px] text-stone-400 font-mono">
                <span>Echo</span>
                <span>·</span>
                <span>Reflecting...</span>
              </div>
              <div className="bg-[#faf9f5] border border-stone-200/90 text-stone-600 px-4 py-3 rounded-2xl rounded-tl-xs text-xs flex items-center gap-2">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-stone-500" />
                <span>Formulating grounded reflection...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Prompts Shelf */}
        <div className="px-4 py-2.5 bg-[#fbf9f5] border-t border-stone-200 flex items-center gap-2 overflow-x-auto text-xs text-stone-600">
          <span className="font-mono text-[10px] uppercase tracking-wider text-stone-400 shrink-0">
            Suggested:
          </span>
          {SUGGESTED_PROMPTS.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(prompt)}
              disabled={isLoading}
              className="px-2.5 py-1 bg-white hover:bg-stone-100 border border-stone-200 rounded-full whitespace-nowrap text-stone-700 transition-colors shrink-0 disabled:opacity-50 cursor-pointer"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <form
          onSubmit={e => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3 bg-white border-t border-stone-200 flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder="Share a reflection, ask for guidance, or explore a theme..."
            disabled={isLoading}
            className="flex-1 text-xs px-4 py-2.5 border border-stone-200 rounded-xl focus:outline-none focus:border-stone-800 disabled:bg-stone-50"
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="px-4 py-2.5 bg-stone-900 text-stone-100 rounded-xl text-xs font-medium hover:bg-stone-800 disabled:opacity-40 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Send</span>
          </button>
        </form>
      </div>

      {/* Ethical Boundaries Banner */}
      <div className="text-[11px] text-stone-500 text-center leading-relaxed">
        <strong>Echo Reflection Guidelines:</strong> Echo offers compassionate self-reflection and dialogue. It never provides psychiatric diagnoses, therapeutic clinical treatments, or causal claims about your life events.
      </div>
    </div>
  );
};
